<?php

namespace App;

class Controller
{
    public static function index()
    {
        return "home from controller";
    }

    public static function about()
    {
        return "about from controller";
    }
}