<?php

namespace App;

interface Renderable
{
    public function render();
}