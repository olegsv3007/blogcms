<?php

return [
    'mysql' => [
        'host' => 'localhost',
        'username' => 'root',
        'password' => '',
        'name' => 'cmsdb',
    ]
];