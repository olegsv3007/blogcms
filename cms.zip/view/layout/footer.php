</main>
</div>
<footer>
    <div class="container-fluid bg-dark">
        <div class="row justify-content-center">
            <div class="footer-brand text-light font-weight-bold m-4">MyBlog.example</div>
        </div>
    </div>
</footer>
<?php
require_once 'base/footer.php';
?>
