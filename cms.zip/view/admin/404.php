<?php
require_once VIEW_DIR . '/layout/admin_header.php';
?>
<h2>Страница не найдена</h2>
<?php
require_once VIEW_DIR . '/layout/admin_footer.php';
?>