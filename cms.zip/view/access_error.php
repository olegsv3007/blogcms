<?php
require_once VIEW_DIR . '/layout/header.php';
?>
<h2>Недостаточно прав для доступа к странице</h2>
<?php
require_once VIEW_DIR . '/layout/footer.php';
?>