<?php
require_once VIEW_DIR . '/layout/header.php';
?>
<h2>Страница не найдена</h2>
<?php
require_once VIEW_DIR . '/layout/footer.php';
?>