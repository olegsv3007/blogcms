<?php
require_once 'layout/header.php';
?>

<?php
require_once 'layout/footer.php';
?>