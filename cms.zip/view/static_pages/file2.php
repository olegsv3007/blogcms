<?php require_once VIEW_DIR . '/layout/header.php';?>
<h2>Вторая страница</h2>
<?php require_once VIEW_DIR . '/layout/footer.php';?>                   