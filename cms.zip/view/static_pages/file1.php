<?php require_once VIEW_DIR . '/layout/header.php';?>
<main>
    <div class="container-fluid">
    <h3>Hello</h3>
    </div>
</main>
<?php require_once VIEW_DIR . '/layout/footer.php';?>                    